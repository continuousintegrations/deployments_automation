#!/bin/bash
# build_date=29.11.2016

source ~/bin/location_finder

#--------------------------------------------------------------------#
#------------------------- DIRECTORIES ------------------------------#
#--------------------------------------------------------------------#

LBU_HOME="${SHOW_DEFAULT_PATH}/liquibase"
LBU_LOGS="$LBU_HOME/utilities/Logs"
TIME_FILE=`date +\[%F]\[%H:%M:%S]`

#--------------------------------------------------------------------#
#-------------------- REMOVE TYTAN SESSIONS -------------------------#
#--------------------------------------------------------------------#

echo "--------------------------------------------------"
echo "Remove tytan sessions"
echo "--------------------------------------------------"

cd ${LBU_HOME}
./bin/ant `grep ^TYTAN_SESSIONS ~/bin/servers.arr | awk '{print $2}'` -Dupgrade.version=tytan-sessions -Dcontext=`grep ^TYTAN_SESSIONS ~/bin/servers.arr | awk '{print $2}'` -Dfile.encoding=UTF8 2>&1 | tee -a $LBU_LOGS/tytan-sessions-context-${TIME_FILE}.log

echo "--------------------------------------------------"
echo "Checking status of tytan sessions changeset"
echo "--------------------------------------------------"
if grep 'BUILD FAILED' ${LBU_LOGS}/tytan-sessions-context-${TIME_FILE}.log; then 
	echo "Deployment failed because of tytan sessions changset error. Exiting."
	exit 1 
else
	echo "Tytan sessions changeset executed successfully"
fi
