begin
  for rec in (SELECT sid, serial# FROM v$session WHERE module='tytan.exe') 
  loop
    sys.kill_session(rec.sid, rec.serial#);
  end loop;
end;  