#!/bin/bash
#Build_date=25.05.2016

source ~/bin/location_finder

#--------------------------------------------------------------------#
#------------------------- DIRECTORIES ------------------------------#
#--------------------------------------------------------------------#

LBU_HOME="${SHOW_DEFAULT_PATH}/liquibase"
LBU_LOGS="$LBU_HOME/utilities/Logs"
TIME_FILE=`date +\[%F]\[%H:%M]`

#--------------------------------------------------------------------#
#------------------------ MBCORE BACKUP -----------------------------#
#--------------------------------------------------------------------#

echo "--------------------------------------------------"
echo "MBCore backup"
echo "--------------------------------------------------"

cd $LBU_HOME
./bin/ant mbcore-deploy-context -Dupgrade.version=R6 -Dcontext=upgrade -Dfile.encoding=UTF8 2>&1 | tee -a $LBU_LOGS/mbcore-deploy-context-$TIME_FILE.log

echo "--------------------------------------------------"
echo "Checking status of MBCore backup"
echo "--------------------------------------------------"
if grep 'BUILD FAILED' $LBU_LOGS/mbcore-deploy-context-$TIME_FILE.log; then 
	echo "Build failed because of unsuccessful MBCore backup. Exiting."
	exit 1 
else
	echo "Build successful"
fi
