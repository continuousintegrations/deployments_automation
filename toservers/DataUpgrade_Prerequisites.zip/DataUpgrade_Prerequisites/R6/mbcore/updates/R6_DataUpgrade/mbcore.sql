DECLARE
	MBCore_NameTable VARCHAR2(32);
	Counter int;
BEGIN 
	MBCore_NameTable := 'tp7msg' || TO_CHAR(SYSDATE, 'yyyymmdd');
  select count(*) into Counter from user_tables where table_name = 'TP7MSG'||TO_CHAR(SYSDATE, 'YYYYMMDD');
  if Counter = 0 then
    EXECUTE IMMEDIATE 'CREATE TABLE ' || 'TP7MSG'||TO_CHAR(SYSDATE, 'YYYYMMDD') ||' as select * from tp7messagequeue';
  else 
	EXECUTE IMMEDIATE 'drop table ' || 'TP7MSG'||TO_CHAR(SYSDATE, 'YYYYMMDD') || ' cascade constraints';
    EXECUTE IMMEDIATE 'CREATE TABLE ' || 'TP7MSG'||TO_CHAR(SYSDATE, 'YYYYMMDD') ||' as select * from tp7messagequeue';
	end if;
END;