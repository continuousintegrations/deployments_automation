#!/bin/bash


TUM_HOME=$(cd $(dirname $0) ; cd .. ; pwd)

true=0
false=1

verbose=$false
verboseArg=""

logInfo()
{
    [[ $verbose -eq $true  ]] && echo "$1"
    return $true
}

normalFailure()
{
    echo "Error. $1"
    return $false
}

fatalFailure()
{
    echo "Error. $1"
    exit $false
}

##
# Validate solution key is to disable possibillity to install the solution for a different env
# we check hostname written to the package with the current hostname
validateSolutionKey()
{
    logInfo "Checking the solution key."

    solutionkey=${TUM_SOLUTIONS_HOME}/solutionkey

    hostname=`hostname`

    grep --quiet '^all$'   $solutionkey ||
    grep --quiet $hostname $solutionkey ||
        normalFailure "You are trying to install the solution on an environment ${hostname} but the solution is for a different one. See the ${solutionkey}."
}

validateVersionVariablePresence()
{
    logInfo "Checking the version variables presence."

    [[ "${TUM_HTTPD_VERSION}x"     != "x" ]] &&
    [[ "${TUM_TOMCAT_VERSION}x"    != "x" ]] &&
    [[ "${TUM_RESTAPI_VERSION}x"   != "x" ]] &&
    [[ "${TUM_CAS_VERSION}x"       != "x" ]] &&
    [[ "${TUM_DEVOPS_VERSION}x"    != "x" ]] &&
    [[ "${TUM_SOLUTIONS_VERSION}x" != "x" ]] ||
    normalFailure "Version configuration seems to be invalid. See the ${TUM_SOLUTIONS_HOME}/packages."

}

validateVersionPresence()
{
    logInfo "Checking the version presence."

    checkVersionComponentPresence tum-httpd   ${TUM_HTTPD_VERSION}     &&
    checkVersionComponentPresence tum-cas     ${TUM_CAS_VERSION}       &&
    checkVersionComponentPresence tum-restapi ${TUM_RESTAPI_VERSION}   ||
    normalFailure "Version is invalid. Check your installation in ${TUM_SOLUTIONS_HOME}."
}

stopServices()
{
    logInfo "Stopping all TUM services"
    ${TUM_HOME}/bin/tum.sh $verboseArg stop
}

startServices()
{
    logInfo "Starting all TUM services"
    [[ $verbose -eq $true  ]]                  &&
        ${TUM_HOME}/bin/tum.sh --verbose start ||
        ${TUM_HOME}/bin/tum.sh           start
}


showStartupInfo()
{
    logInfo "Starting the switch to solution ${TUM_SOLUTIONS_VERSION}."
}

showFinalInfo()
{
    logInfo "OK. Version updated to ${TUM_SOLUTIONS_VERSION}."
    echo    "OK. Version updated to ${TUM_SOLUTIONS_VERSION}."
    return $true
}

checkVersionComponentPresence()
{
    component=$1
    version=$2

    [[ -d ${TUM_SOLUTIONS_HOME}/${component}-${version} ]]
}

# the httpd link is required for backward compatibility. All configuration in httpd refers to files in /opt/tum/httpd/...
linkHttpDir()
{
    [[ -s ${TUM_HOME}/httpd ]] || ln -s  ${TUM_HOME}/tum-httpd ${TUM_HOME}/httpd
}

linkComponent()
{
    component=$1
    version=$2

    logInfo "Linking the component ${component} in version ${version}."

    # Remove if it is a symbolic link
    [[ -h ${TUM_HOME}/${component} ]]  &&
        rm -f ${TUM_HOME}/${component} &&
        logInfo "Removed link ${TUM_HOME}/${component}"

    # now it should not exist
    [[ -e ${TUM_HOME}/${component} ]] &&
        fatalFailure "The ${TUM_HOME}/${component} should not exist. Please contact support team."

    # create a link
    [[ -d ${TUM_SOLUTIONS_HOME}/${component}-${version} ]]                       &&
    ln -s ${TUM_SOLUTIONS_HOME}/${component}-${version} ${TUM_HOME}/${component} &&
    logInfo       "${component} linked to ${component}-${version}"               ||
    normalFailure "Cannot create link for ${component}-${version}"
}

printUsage()
{
    echo "Usage: $0 <--verbose> <--start|--stop|--switch> <solution_name>"
    cat << END_OF_TEXT

    The script switches versions of components used by TUM.

    solution_name - solution to switch is one of folder in ${TUM_HOME}/versions
                    The name of the solutions is also the branch name in the tum-solutions project.
                    See git@r7:tum/tum-solutions.git for more details.

    options

        --verbose

          The script is more verbose. Prints addtional messages for diagnosis.

        --start

          Starts TUM. ex. $0 --verbose --start

        --stop

          Stops TUM. ex. $0 --verbose --stop

        --switch

          Performs the switch . ex. $0 --verbose --switch 7.X

END_OF_TEXT
}

validate()
{
    TUM_SOLUTIONS_VERSION=$1

    # this code prevents from non parsed options to be treated as a solution name
    if [[ "${TUM_SOLUTIONS_VERSION:0:2}" = "--" ]]; then
        printUsage
        fatalFailure "Solution name cannot start with --. Parsed solution name is ${TUM_SOLUTIONS_VERSION}. Check your command line and spelling of options passed to the script."
    fi

    if [[ "x${TUM_SOLUTIONS_VERSION}" = "x" ]]; then
        printUsage
        fatalFailure "Empty solution name."
    fi

    TUM_SOLUTIONS_HOME=${TUM_HOME}/versions/${TUM_SOLUTIONS_VERSION}

    if [[ ! -d ${TUM_SOLUTIONS_HOME} ]]; then
        printUsage
        fatalFailure "${TUM_SOLUTIONS_VERSION} is not a solution name since cannot find the ${TUM_SOLUTIONS_HOME} folder."
    fi

    if [[ ! -f ${TUM_SOLUTIONS_HOME}/packages ]]; then
        printUsage
        fatalFailure "Cannot find solution packages in ${TUM_SOLUTIONS_HOME}/packages."
    fi


    if [[ $verbose -eq $true  ]]; then
        log=/dev/tty
    else
        log=/dev/null
    fi

    . ${TUM_SOLUTIONS_HOME}/packages
}

stop_and_switch()
{
    showStartupInfo                                   &&
    validateSolutionKey                               &&
    validateVersionVariablePresence                   &&
    validateVersionPresence                           &&
    stopServices                                      &&
    linkComponent tum-httpd   ${TUM_HTTPD_VERSION}    &&
    linkHttpDir                                       &&
    linkComponent tum-cas     ${TUM_CAS_VERSION}      &&
    linkComponent tum-restapi ${TUM_RESTAPI_VERSION}  &&
    showFinalInfo                                     ||
    normalFailure "Cannot switch to ${TUM_SOLUTIONS_VERSION}."
}

switch()
{
    showStartupInfo                                   &&
    validateSolutionKey                               &&
    validateVersionVariablePresence                   &&
    validateVersionPresence                           &&
    stopServices                                      &&
    linkComponent tum-httpd   ${TUM_HTTPD_VERSION}    &&
    linkHttpDir                                       &&
    linkComponent tum-cas     ${TUM_CAS_VERSION}      &&
    linkComponent tum-restapi ${TUM_RESTAPI_VERSION}  &&
    startServices                                     &&
    showFinalInfo                                     ||
    normalFailure "Cannot switch to ${TUM_SOLUTIONS_VERSION}."
}

##
# main part of the program
#

while (true)
do
    option=$1

    case ${option} in
        (--verbose)         verbose=$true
                            verboseArg="--verbose";;
        (--stop)            stopServices                               &&
                            logInfo "OK. Tum stopped."                 ||
                            fatalFailure "Cannot stop TUM."
                            exit $true;;
        (--start)           startServices                              &&
                            logInfo "OK. Tum started."                 ||
                            fatalFailure "Cannot start TUM."
                            exit $true;;
        (--switch)          validate $2                                &&
                            stop_and_switch                            &&
                            logInfo "OK. Tum switched and stopped."    ||
                            fatalFailure "Cannot switch TUM."
                            exit $true;;
        (*)                 break ;;
    esac
    shift
done



validate $1
switch
