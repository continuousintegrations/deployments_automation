#!/bin/bash


TUM_HOME=$(cd $(dirname $0) ; cd .. ; pwd)

TUM_CAS_HOME=${TUM_HOME}/tum-cas/

true=0
false=1

verbose=$false

wait4ok()
{
    timetowait=20
    while [[ ! -f ${TUM_CAS_HOME}/catalina_pid ]];
    do
        let timetowait-=1
        if [[ $timetowait -eq 0 ]]; then
            break
        fi
        if [[ $verbose -eq $true  ]]; then
            echo "Waiting for ${TUM_CAS_HOME}/catalina_pid"
        fi
        sleep 1
    done
}

print_usage()
{
    echo "Usage: $0 <start|restart|stop|status>"
    cat << END_OF_TEXT

    start
        Starts TUM CAS service.

    restart
        Restarts TUM CAS service.

    stop
        Stops TUM CAS service.

    status
        Shows status of TUM CAS service.

    options

        --verbose

          The script is more verbose. Prints addtional messages during startup for diagnosis.

END_OF_TEXT
}

normalFailure()
{
    echo "Error. $1"
    return $false
}

fatalFailure()
{
    echo "Error. $1"
    exit $false
}

start_tomcat()
{
    if [[ $TUM_CAS_START -eq $false ]]; then
        echo "OK. TUM CAS should not be started. See the tum-profile file.";
        return $true;
    fi

    cd ${TUM_CAS_HOME}/bin

    status > /dev/null 2>&1
    if [[ $? -eq $true ]]; then
        pid=`cat ${TUM_CAS_HOME}/catalina_pid 2> /dev/null`
        echo "OK. TUM CAS service is already running. PID: ${pid}";
        return $true;
    else
        # the 2 remove commands below workarounds the problem with memory leak in tomcat near jdbc connection
        rm -rf ${TUM_CAS_HOME}/webapps/cas
        rm -rf ${TUM_CAS_HOME}/work/Catalina/localhost/cas
    fi

    if [[ $verbose -eq $true  ]]; then
        ./startup.sh
    else
        ./startup.sh > /dev/null 2>&1
    fi
    wait4ok
    if [[ $verbose -eq $true  ]]; then
        status
    else
        status > /dev/null 2>&1
    fi

    if [[ $? -eq $true ]]; then
        pid=`cat ${TUM_CAS_HOME}/catalina_pid 2> /dev/null`
        echo "OK. TUM CAS service is running. PID: ${pid}"
    else
        normalFailure "TUM CAS service is not running at the moment."
    fi
}

stop_tomcat()
{
    if [[ ! -f ${TUM_CAS_HOME}/catalina_pid ]]; then
        if [[ $verbose -eq $true  ]]; then
            echo "Cannot find ${TUM_CAS_HOME}/catalina_pid. I assume the service is not running at the moment.";
        fi
        echo "OK. TUM CAS service is not running at the moment.";
        return $true;
    fi

    cd ${TUM_CAS_HOME}/bin
    if [[ $verbose -eq $true  ]]; then
        ./shutdown.sh
    else
        ./shutdown.sh > /dev/null 2>&1
    fi
    timetowait=4
    while [[ ! -f ${TUM_CAS_HOME}/catalina_pid ]];
    do
        case "$spin" in "")spin='/';; '/')spin='-';; '-')spin='\';; '\')spin='|';; '|')spin='/';; esac
        if [[ $verbose -eq $true  ]]; then
            echo -ne "\rWaiting for termination... $spin"
        fi
        let timetowait-=1
        if [[ $timetowait -eq 0 ]]; then
            if [[ $verbose -eq $true  ]]; then
                echo -e "\nWaiting for termination end"
            fi
            break
        fi
        sleep 1
    done
    echo "OK. TUM CAS service has stopped correctly."
}

status()
{
    if [[ ! -f ${TUM_CAS_HOME}/catalina_pid ]]; then
        if [[ $verbose -eq $true  ]]; then
            echo "Cannot find ${TUM_CAS_HOME}/catalina_pid. I assume the service is not running at the moment.";
        fi
        echo "Stopped. TUM CAS service is not running at the moment.";
        return $false;
    else
        pid=`cat ${TUM_CAS_HOME}/catalina_pid 2> /dev/null`
        username=`whoami`
        ps -u ${username} | grep -w ${pid} &>/dev/null
        if [[ $? -eq $true ]]; then
            echo "Running. TUM CAS service is running at the moment. PID: ${pid}.";
            return $true;
        else
            if [[ $verbose -eq $true  ]]; then
                echo "The pid file has been found but no process (died or killed). PID: ${pid}. Removing ${TUM_CAS_HOME}/catalina_pid.";
            fi

            rm -f ${TUM_CAS_HOME}/catalina_pid

            echo "Stopped. TUM CAS service is not running at the moment.";
            return $false;
        fi
    fi

}

restart_tomcat()
{
    stop_tomcat   &&
    start_tomcat
}

checkCaller()
{
    correctUser=`ls -nl $0 | awk '{print $3}'`

    [[ $correctUser == $UID ]]
}

loadTumProfile()
{
    tumprofile=${TUM_HOME}/bin/tum-profile

    if [[ -f ${tumprofile} ]]; then
        . ${tumprofile}
    else
        TUM_RESTAPI_START=$true    # start tum-httpd by default
        TUM_RESTAPI_MEM=128        # 128 MB by default
        TUM_CAS_START=$true      # start tum-cas by default
        TUM_HTTPD_START=$true    # start tum-httpd by default
    fi
}

checkCaller || fatalFailure "Only owner of the script may run it. Please use su command!"

loadTumProfile

while (true)
do
    option=$1

    case ${option} in
        (--verbose)   verbose=$true;;
        (*)           break ;;
    esac
    shift
done

action=$1
shift

case ${action} in
    (start)       start_tomcat ;;
    (restart)     restart_tomcat ;;
    (stop)        stop_tomcat ;;
    (status)      status ;;
    (*)           print_usage ; exit $false ;;
esac

exit $?



