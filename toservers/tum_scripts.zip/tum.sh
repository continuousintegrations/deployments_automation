#!/bin/bash

#######################################################
# The script manages TUM services
##

TUM_HOME=$(cd $(dirname $0) ; cd .. ; pwd)
TUM_BIN=${TUM_HOME}/bin

true=0
false=1

print_usage()
{

    echo "Usage: $0 <start|restart|stop|status|version>"
    cat << END_OF_TEXT
    The $0 script manages all TUM components, which are:
      - TUM rest API
      - TUM httpd
      - TUM CAS

     start
         Starts all TUM components.

     restart
         Restarts all TUM components

     stop
         Stops all TUM components.

     status
         Return status of all TUM components.

     version
         Prints version information.

END_OF_TEXT
}

start_app()
{
    ${TUM_BIN}/tum-restapi.sh start ; s1=$?
    ${TUM_BIN}/tum-httpd.sh   start ; s2=$?
    ${TUM_BIN}/tum-cas.sh     start ; s3=$?

    [[ $s1 -eq $true ]] &&
    [[ $s2 -eq $true ]] &&
    [[ $s3 -eq $true ]]
}

restart_app()
{
    ${TUM_BIN}/tum-restapi.sh restart  ; s1=$?
    ${TUM_BIN}/tum-cas.sh     restart  ; s2=$?
    ${TUM_BIN}/tum-httpd.sh   restart  ; s3=$?


    [[ $s1 -eq $true ]] &&
    [[ $s2 -eq $true ]] &&
    [[ $s3 -eq $true ]]
}

stop_app()
{
    ${TUM_BIN}/tum-restapi.sh stop  ; s1=$?
    ${TUM_BIN}/tum-httpd.sh   stop  ; s2=$?
    ${TUM_BIN}/tum-cas.sh     stop  ; s3=$?

    [[ $s1 -eq $true ]] &&
    [[ $s2 -eq $true ]] &&
    [[ $s3 -eq $true ]]
}

status()
{
    ${TUM_BIN}/tum-restapi.sh status ; s1=$?
    ${TUM_BIN}/tum-httpd.sh   status ; s2=$?
    ${TUM_BIN}/tum-cas.sh     status ; s3=$?

    [[ $s1 -eq $true ]] &&
    [[ $s2 -eq $true ]] &&
    [[ $s3 -eq $true ]]
}

version()
{
    tumrestapilink=`readlink ${TUM_BIN}/../tum-restapi`
    if [[ "x$tumrestapilink" != "x" ]]; then
        parentdir=`dirname $tumrestapilink`
        TUM_SOLUTIONS_VERSION=`basename $parentdir`
        [[ -f $parentdir/packages ]]                                &&
        . $parentdir/packages                                       ||
        echo    "Error. Cannot guess current version information!"

        cat << END_OF_TEXT
TUM version information:
  TUM-SOLUTIONS ${TUM_SOLUTIONS_VERSION}
  TUM-HTTPD     ${TUM_HTTPD_VERSION}
  TUM-TOMCAT    ${TUM_TOMCAT_VERSION}
  TUM-RESTAPI   ${TUM_RESTAPI_VERSION}
  TUM-CAS       ${TUM_CAS_VERSION}
  TUM-DEVOPS    ${TUM_DEVOPS_VERSION}

END_OF_TEXT

    else
        echo    "Error. Cannot guess current version information"
        return  $false
    fi

}

fatalFailure()
{
    echo "Error. $1"
    exit $false
}

checkCaller()
{
    correctUser=`ls -nl $0 | awk '{print $3}'`

    [[ $correctUser == $UID ]]
}

#Script starts here

checkCaller || fatalFailure "Only owner of the script may run it. Please use su command!"


while (true)
do
  option=$1

  case ${option} in
      (--verbose)   verbose=$true;;
      (*)           break ;;
  esac
  shift
done


action=$1
shift

case ${action} in
    (start)       start_app ;;
    (restart)     restart_app ;;
    (stop)        stop_app ;;
    (status)      status ;;
    (version)     version ;;
    (*)           print_usage ; exit $false ;;
esac

exit $?
