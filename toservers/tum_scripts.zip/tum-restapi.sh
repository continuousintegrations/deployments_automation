#!/bin/bash

#######################################################
# The script menages TUM rest API.
# TUM rest API should be started, stopped using this script only.
##


TUM_HOME=$(cd $(dirname $0) ; cd .. ; pwd)
TUM_RESTAPI_HOME=${TUM_HOME}/tum-restapi

myservice="TUM rest API"

runningpid=${TUM_RESTAPI_HOME}/RUNNING_PID


true=0
false=1

## see options description for the variable meaning
verbose=$false
jvmdebug=$false
donotwait=$false


#######################################################
# startup settings for tum-restapi
##
httpport=9100
#httpport=disabled

httpsport=9200

#######################################################
# prints usage
##
print_usage()
{
    echo "Usage: $0 <options> <start|restart|stop|status|version>"
    cat << END_OF_TEXT

    start
        Starts $myservice.
        The script uses nohup commands so the shell session may be closed.
        If script fails to run $myservice it will print start log.

    restart
        Restarts $myservice.

    stop
        Stops $myservice.

    status
        Return status of $myservice.

    options

        --verbose

          The script is more verbose. Prints addtional messages during startup for diagnosis.

        --jvmdebug

          Enables jvm debug port on the default port which is 9106
          The option have sense for start command only, since this is the only command passes the settings to the service.

        --donotwait

          Does not wait for the service to start. By default scripts ends when the service starts to respond.
          The option may be useful when running multiple services and cumulative startup time is important.
          The option have sense for start command only, since this is the only command which waits.


    sample usage

        tum-restapi.sh start

          Starts the service

        tum-restapi.sh --verbose --jvmdebug start

          Starts the service with java remote debug enabled.
          Script is more talkative (see --verbose)

END_OF_TEXT
}

normalFailure()
{
    echo "Error. $1"
    return $false
}

fatalFailure()
{
    echo "Error. $1"
    exit $false
}


#######################################################
# Checks if app is up
##
checkTumIsUp()
{
    response=`curl --insecure -s -k http://localhost:$httpport/admin/ping`
    [[ $response = "OK" ]]
}

#######################################################
# Checks if tum died just after start
##
tumHasDied()
{
    pid=`cat $runningpid 2> /dev/null`
    username=`whoami`
    ps -u ${username} | grep -w $pid &>/dev/null

    if [[ $? -ne $true ]]; then
        if [[ $verbose -eq $true  ]]; then
            echo "The $runningpid file has been found but no process (died or killed). PID: $pid. Probably $myservice has died!";
        fi
        rm -f $runningpid
        return $true;
    fi
    return $false
}

#######################################################
# waits for at most 20 seconds for the pid file which appears when jvm process starts
# then it waits for at most 300 seconds (5 minutes) for the response from curl
# or immadiatelly
##
wait4ok()
{
    # wait for 20 seconds for the start command which runs jvm
    timetowait=20
    while [[ ! -f $runningpid ]];
    do
        let timetowait-=1
        if [[ $timetowait -eq 0 ]]; then
            break
        fi
        if [[ $verbose -eq $true  ]]; then
            case "$spin" in "")spin='/';; '/')spin='-';; '-')spin='\';; '\')spin='|';; '|')spin='/';; esac
            echo -ne "\rWaiting for $runningpid... $spin"
        fi
        sleep 1
    done

    if [[ ! -f $runningpid ]]; then
        if [[ $verbose -eq $true  ]]; then
            echo -e "\nThe $runningpid file has not been found. $myservice has not started. Please check if java is available and installation files are correct!";
        fi
        return $false;
    fi

    timetowait=0
    while [[ $timetowait -lt 300  ]];   # wait for 5 minutes at most
    do
        if [[ $verbose -eq $true  ]]; then
            case "$spin" in "")spin='/';; '/')spin='-';; '-')spin='\';; '\')spin='|';; '|')spin='/';; esac
            echo -ne "\rChecking if $myservice is responding... $spin"
        fi

        tumHasDied   # process has started since we have $runningpid but the process does not exist
        if [[ $? -eq $true ]]; then
            if [[ $verbose -eq $true  ]]; then
                echo -e "\n$myservice died after $timetowait [sec]"
            fi
            break
        fi

        checkTumIsUp

        if [[ $? -eq $true ]]; then
            if [[ $verbose -eq $true  ]]; then
                echo -e "\n$myservice is responding after $timetowait [sec]"
            fi
            break
        fi
        let timetowait+=1
        sleep 1
    done
}  # wait4ok

#######################################################
# starts TUM rest API
##
start_TUM()
{
    if [[ $TUM_RESTAPI_START -eq $false ]]; then
        echo "OK. $myservice should not be started. See the tum-profile file.";
        return $true;
    fi


    JVMDEBUG=""

    startlog=${TUM_RESTAPI_HOME}/logs/tum-restapi-start-`date "+%Y-%m-%d_%H-%M-%S"`.log
    if [[ ! -d ${TUM_RESTAPI_HOME}/logs ]]; then
        mkdir ${TUM_RESTAPI_HOME}/logs
    fi

    if [[ $verbose -eq $true  ]]; then
        echo "Checking the status ..."
        status
    else
        status > /dev/null 2>&1
    fi

    if [[ $? -eq $true ]]; then
        pid=`cat $runningpid 2> /dev/null`
        echo "OK. $myservice is already running. PID: ${pid}";
        return $true;
    fi

    if [[ $jvmdebug -eq $true ]]; then
        JVMDEBUG="-jvm-debug 9106"
    fi

    cd ${TUM_RESTAPI_HOME}  # change dir to make "logs" be in the context of restapi home

    nohup ${TUM_RESTAPI_HOME}/bin/tum-restapi                    \
        -Dconfig.file=${TUM_RESTAPI_HOME}/conf/application.conf  \
        -Dlogger.file=${TUM_RESTAPI_HOME}/conf/logger.xml        \
        -Dhttp.port=$httpport $JVMDEBUG                          \
        -mem $TUM_RESTAPI_MEM                                    \
        -J-XX:+HeapDumpOnOutOfMemoryError                        \
        -J-XX:HeapDumpPath=${TUM_RESTAPI_HOME}/logs              \
      > $startlog 2>&1 &

    if [[ $donotwait -eq $true ]]; then
        echo "OK. $myservice has been submitted.";
        return $true;
    fi

    wait4ok

    if [[ $verbose -eq $true  ]]; then
        status
    else
        status > /dev/null 2>&1
    fi

    if [[ $? -eq $true ]]; then
        pid=`cat $runningpid 2> /dev/null`
        echo "OK. $myservice is running. PID: ${pid}";
    else
        if [[ $verbose -eq $true  ]]; then
            cat $startlog
        fi
        normalFailure "$myservice is not running at the moment.";
    fi

} # start_TUM

#######################################################
# stops TUM rest API
##
kill_Tum()
{
    pid=$1

    if [[ $verbose -eq $true  ]]; then
        echo "Trying to kill the $pid process."
    fi


    # SIGTERM may not be enough
    kill -SIGTERM $pid

    timetowait=4

    # wait 5 seconds for kill success
    while `kill -0 $pid > /dev/null 2>&1`;
    do
        case "$spin" in "")spin='/';; '/')spin='-';; '-')spin='\';; '\')spin='|';; '|')spin='/';; esac
        if [[ $verbose -eq $true  ]]; then
            echo -ne "\rWaiting for termination... $spin"
        fi
        let timetowait-=1
        if [[ $timetowait -eq 0 ]]; then
            if [[ $verbose -eq $true  ]]; then
                echo -e "\nWaiting for termination end"
            fi
            break
        fi
        sleep 1
    done

    while `kill -0 $pid > /dev/null 2>&1`;
    do
        case "$spin" in "")spin='/';; '/')spin='-';; '-')spin='\';; '\')spin='|';; '|')spin='/';; esac
        if [[ $verbose -eq $true  ]]; then
          echo -ne "\rWaiting for successful kill... $spin"
        fi
        kill -9 $pid 2 > /dev/null 2>&1
        sleep 1
    done

    if [[ $verbose -eq $true  ]]; then
        echo -e "\nService killed"
    fi
} # kill_Tum



#######################################################
# stops TUM rest API
##
stop_TUM()
{
    if [[ ! -f $runningpid ]]; then
        if [[ $verbose -eq $true  ]]; then
            echo "Cannot find $runningpid. I assume the service is not running at the moment.";
        fi
        echo "OK. $myservice is not running at the moment.";
        return $true;
    fi

    pid=`cat $runningpid 2> /dev/null`

    if [[ $verbose -eq $true  ]]; then
        echo "Stopping $myservice at pid=$pid"
    fi

    kill_Tum $pid &&
        rm -f $runningpid

    if [[ $? -eq $true ]]; then
        echo "OK. $myservice has stopped correctly."
        return $true
    else
        normalFailure "Couldn't stop $myservice"
    fi
}

#######################################################
# returns the status
##
status()
{
    if [[ ! -f $runningpid ]]; then
        echo "Stopped. $myservice is not running at the moment.";
        return $false;
    fi

    tumHasDied

    if [[ $? -eq $true ]]; then
        echo "Stopped. $myservice is not running at the moment.";
        return $false;
    fi

    checkTumIsUp

    if [[ $? -eq $false ]]; then
        echo "Stopped. $myservice is not responding.";
        return $false;
    fi

    if [[ $? -eq $true ]]; then
        echo "Running. $myservice is running at the moment. PID: $pid";
        return $true;
    fi

}

restart_TUM()
{
    stop_TUM   &&
    start_TUM
}

checkCaller()
{
    correctUser=`ls -nl $0 | awk '{print $3}'`

    [[ $correctUser == $UID ]]
}

loadTumProfile()
{
    tumprofile=${TUM_HOME}/bin/tum-profile

    if [[ -f ${tumprofile} ]]; then
        . ${tumprofile}
    else
        TUM_RESTAPI_START=$true    # start tum-httpd by default
        TUM_RESTAPI_MEM=128        # 128 MB by default
        TUM_CAS_START=$true      # start tum-cas by default
        TUM_HTTPD_START=$true    # start tum-httpd by default
    fi
}

checkCaller || fatalFailure "Only owner of the script may run it. Please use su command!"

loadTumProfile

while (true)
do
  option=$1

  case ${option} in
      (--verbose)   verbose=$true;;
      (--jvmdebug)  jvmdebug=$true;;
      (--donotwait) donotwait=$true;;
      (*)           break ;;
  esac
  shift
done

if [[ $verbose -eq $true  ]]; then
    echo "Processing commands with the following options: verbose=$verbose jvmdebug=$jvmdebug donotwait=$donotwait"
fi

action=$1
shift

case ${action} in
    (start)       start_TUM ;;
    (restart)     restart_TUM ;;
    (stop)        stop_TUM ;;
    (status)      status ;;
    (*)           print_usage ; exit $false ;;
esac

exit $?





