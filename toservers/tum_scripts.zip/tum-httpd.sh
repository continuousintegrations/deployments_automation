#!/bin/bash


TUM_HOME=$(cd $(dirname $0) ; cd .. ; pwd)
TUM_HTTPD_HOME=${TUM_HOME}/tum-httpd

true=0
false=1

verbose=$false

print_usage()
{
    echo "Usage: $0 <options>  <start|restart|stop|status|configtest>"
    cat << END_OF_TEXT

    start
        Starts TUM httpd

    restart
        Restarts TUM httpd

    stop
        Stops TUM httpd

    status
        Return status of TUM httpd.

    configtest
        Run a configuration file syntax test.

    options

        --verbose

          The script is more verbose. Prints addtional messages during startup for diagnosis.

    sample usage

        tum-httpd.sh start

          Starts the service

        tum-httpd.sh --verbose configtest

          Validates the configuration and prints some details on standard output.


END_OF_TEXT
}

normalFailure()
{
    echo "Error. $1"
    return $false
}

fatalFailure()
{
    echo "Error. $1"
    exit $false
}


wait4ok()
{
    timetowait=20
    while [[ ! -f ${TUM_HTTPD_HOME}/logs/httpd.pid ]];
    do
        let timetowait-=1
        if [[ $timetowait -eq 0 ]]; then
            break
        fi
        if [[ $verbose -eq $true  ]]; then
            echo "Waiting for ${TUM_HTTPD_HOME}/logs/httpd.pid"
        fi
        sleep 1
    done
}

start_HTTPD()
{
    if [[ $TUM_HTTPD_START -eq $false ]]; then
        echo "OK. TUM httpd should not be started. See the tum-profile file.";
        return $true;
    fi

    status > /dev/null 2>&1
    if [[ $? -eq $true ]]; then
        pid=`cat ${TUM_HTTPD_HOME}/logs/httpd.pid 2> /dev/null`
        echo "OK. TUM httpd service is already running. PID: ${pid}";
        return $true;
    fi
    cd ${TUM_HTTPD_HOME}/bin
    #echo "Starting TUM httpd."
    if [[ $verbose -eq $true  ]]; then
        ./apachectl start
    else
        ./apachectl start > /dev/null 2>&1
    fi
    if [[ $? -ne $true ]]; then
        echo "Error. Something went wrong while starting. Try ./tum-httpd.sh configtest to check config file."
        return $false
    fi
    wait4ok

    status > /dev/null 2>&1


    if [[ $? -eq $true ]]; then
        pid=`cat ${TUM_HTTPD_HOME}/logs/httpd.pid 2> /dev/null`
        echo "OK. TUM httpd service is running. PID: ${pid}";
        return $true;
    else
        echo "Error. TUM httpd service is not running at the moment.";
        return $false;
    fi
}

restart_HTTPD()
{
    cd ${TUM_HTTPD_HOME}/bin
    #echo "Restarting TUM httpd."
    if [[ $verbose -eq $true  ]]; then
        ./apachectl restart
    else
        ./apachectl restart > /dev/null 2>&1
    fi
    if [[ $? -ne $true ]]; then
        echo "Error. Something went wrong while restarting. Try ./tum-httpd.sh configtest to check config file."
        return $false
    fi
    wait4ok
    if [[ $verbose -eq $true  ]]; then
        status
    else
        status > /dev/null 2>&1
    fi

    if [[ $? -eq $true ]]; then
        pid=`cat ${TUM_HTTPD_HOME}/logs/httpd.pid 2> /dev/null`
        echo "OK. TUM httpd service is running. PID: ${pid}";
        return $true;
    else
        echo "Error. TUM httpd service is not running at the moment.";
        return $false;
    fi
}

stop_HTTPD()
{
    if [[ ! -f ${TUM_HTTPD_HOME}/logs/httpd.pid ]]; then
        if [[ $verbose -eq $true  ]]; then
            echo "Cannot find ${TUM_HTTPD_HOME}/logs/httpd.pid. I assume the service is not running at the moment.";
        fi
        echo "OK. TUM httpd is not running at the moment.";
        return $true;
    fi
    cd ${TUM_HTTPD_HOME}/bin
    #echo "Stopping TUM httpd"
    if [[ $verbose -eq $true  ]]; then
        ./apachectl stop
    else
        ./apachectl stop > /dev/null 2>&1
    fi
    if [[ $? -ne $true ]]; then
        echo "Error. Something went wrong while stopping . Try ./tum-httpd.sh configtest to check config file."
        return $false
    fi
    timetowait=4
    while [[ ! -f ${TUM_HTTPD_HOME}/logs/httpd.pid ]];
    do
        case "$spin" in "")spin='/';; '/')spin='-';; '-')spin='\';; '\')spin='|';; '|')spin='/';; esac
        if [[ $verbose -eq $true  ]]; then
            echo -ne "\rWaiting for termination... $spin"
        fi
        let timetowait-=1
        if [[ $timetowait -eq 0 ]]; then
            if [[ $verbose -eq $true  ]]; then
                echo -e "\nWaiting for termination end"
            fi
            break
        fi
        sleep 1
    done
    echo "OK. TUM httpd service has stopped correctly."
    return $true
}

status()
{
    if [[ ! -f ${TUM_HTTPD_HOME}/logs/httpd.pid ]]; then
        echo "Stopped. TUM httpd is not running at the moment.";
        return $false;
    else
        pid=`cat ${TUM_HTTPD_HOME}/logs/httpd.pid 2> /dev/null`
        username=`whoami`
        ps -u ${username} | grep -w ${pid} &>/dev/null
        if [[ $? -eq $true ]]; then
            echo "Running. TUM httpd is running at the moment. PID: ${pid}.";
            return $true;
        else
            if [[ $verbose -eq $true  ]]; then
                echo "The pid file has been found but no process (died or killed). PID: ${pid}. Removing ${TUM_HTTPD_HOME}/logs/httpd.pid.";
            fi

            rm -f ${TUM_HTTPD_HOME}/logs/httpd.pid

            echo "Stopped. TUM httpd is not running at the moment.";
            return $false;
    	fi
    fi
}

configtest()
{
    cd ${TUM_HTTPD_HOME}/bin
    #echo "Restarting TUM httpd."
    if [[ $verbose -eq $true  ]]; then
        ./apachectl configtest
    else
        ./apachectl configtest > /dev/null 2>&1
    fi
    if [[ $? -eq $true ]]; then
        echo "OK. Config test passed."
        return $true
    else
        normalFailure "There are errors in config file."
    fi
}

checkCaller()
{
    correctUser=`ls -nl $0 | awk '{print $3}'`

    [[ $correctUser == $UID ]]
}

loadTumProfile()
{
    tumprofile=${TUM_HOME}/bin/tum-profile

    if [[ -f ${tumprofile} ]]; then
        . ${tumprofile}
    else
        TUM_RESTAPI_START=$true    # start tum-httpd by default
        TUM_RESTAPI_MEM=128        # 128 MB by default
        TUM_CAS_START=$true      # start tum-cas by default
        TUM_HTTPD_START=$true    # start tum-httpd by default
    fi
}

checkCaller || fatalFailure "Only owner of the script may run it. Please use su command!"

loadTumProfile

while (true)
do
    option=$1

    case ${option} in
        (--verbose)   verbose=$true;;
        (*)           break ;;
    esac
    shift
done
action=$1
shift

case ${action} in
    (start)       start_HTTPD ;;
    (stop)        stop_HTTPD ;;
    (status)      status ;;
    (restart)     restart_HTTPD ;;
    (configtest)  configtest ;;
    (*)           print_usage ; exit $false ;;
esac

exit $?



